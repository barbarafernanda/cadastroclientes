﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CadastroClientes.Models
{
    public class TelefoneModel
    {
        public string IdentificacaoTelefone { get; set; }
        public string DDD { get; set; }
        public string Telefone { get; set; }
    }
}
