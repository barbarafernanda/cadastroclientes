﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CadastroClientes.Data;
using CadastroClientes.Helpers;
using CadastroClientes.Models;
using Microsoft.AspNetCore.Mvc;

namespace CadastroClientes.Controllers
{
    public class ClientesController : Controller
    {
        private readonly ClientesDbContext _db;

        public ClientesController(ClientesDbContext db)
        {
            _db = db;
        }

        public IActionResult Index()
        {
            return View();
        }

        public JsonResult List(int current,int rowCount,string sort, string searchPhrase)
        {
            Pagination<Cliente> model;

            if (!string.IsNullOrEmpty(searchPhrase))
            {
                model = _db.Clientes.Where(x => x.Nome.Contains(searchPhrase)).Pagination(current);
            }
            else
            {
                model = _db.Clientes.Pagination(current);
            }

            //return Json(model);

            return null;
        }

        [HttpGet]
        public IActionResult Create(int? clienteId)
        {
            ClienteModel model;

            if (clienteId.HasValue )
            {
                var cliente = _db.Clientes.FirstOrDefault(x => x.ID == clienteId);
                model = new ClienteModel(cliente);
            }
            else
            {
                model = new ClienteModel();
            }

            return View(model);
        }

        [HttpPost]
        public JsonResult Create([FromBody]ClienteModel model)
        {
            try
            {
                var novoCliente = new Cliente
                {
                    CPF = model.CPF,
                    DataNascimento = model.DataNascimento,
                    Nome = model.Nome,
                    RG = model.RG,
                    Facebook = model.Facebook,
                    Instagram = model.Instagram,
                    Linkedin = model.Linkedin,
                    Twitter = model.Twitter,
                };

                foreach (var endereco in model.Enderecos)
                {
                    novoCliente.Enderecos.Add(new Endereco
                    {
                        Bairro = endereco.Bairro,
                        CEP = endereco.CEP,
                        Cidade = endereco.Cidade,
                        Complemento = endereco.Complemento,
                        Estado = endereco.Estado,
                        IdentificacaoEndereco = endereco.NomeEndereco,
                        Logradouro = endereco.Logradouro,
                        Numero = endereco.Numero
                    });
                }

                foreach (var telefone in model.Telefones)
                {
                    novoCliente.Telefones.Add(new Telefone
                    {
                        DDD = telefone.DDD,
                        IdentificacaoTelefone = telefone.IdentificacaoTelefone,
                        NumeroTelefone = telefone.Telefone
                    });
                }

                _db.Clientes.Add(novoCliente);
                _db.SaveChanges();
            }
            catch (Exception e)
            {
              return  Json(new { message = "Ocorreu um erro." });
            }

            return Json(new { message = "Cadastro efetuado com sucesso."});
        }
    }
}