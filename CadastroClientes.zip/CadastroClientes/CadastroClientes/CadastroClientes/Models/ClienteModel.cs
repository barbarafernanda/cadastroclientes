﻿using CadastroClientes.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CadastroClientes.Models
{
    public class ClienteModel : IValidatableObject
    {
        [Required(ErrorMessage = "Nome é obrigatório.")]
        public string Nome { get; set; }

        [Required(ErrorMessage = "Data de nascimento é obrigatório." )]
        public DateTime? DataNascimento { get; set; }

        [Required(ErrorMessage = "RG é obrigatório.")]
        public string RG { get; set; }

        [Required(ErrorMessage = "CPF é obrigatório.")]
        public string CPF { get; set; }

        public IList<EnderecoModel> Enderecos { get; set; }

        public IList<TelefoneModel> Telefones { get; set; }

        public string Facebook { get; set; }
        public string Linkedin { get; set; }
        public string Twitter { get; set; }
        public string Instagram { get; set; }



        public ClienteModel()
        {
            this.Enderecos = new List<EnderecoModel>();
            this.Telefones = new List<TelefoneModel>();
        }

        public ClienteModel(Cliente cliente) : this()
        {
            this.Nome = cliente.Nome;
            this.DataNascimento = cliente.DataNascimento;
            this.RG = cliente.RG;
            this.CPF = cliente.CPF;
            this.Facebook = cliente.Facebook;
            this.Twitter = cliente.Twitter;
            this.Linkedin = cliente.Linkedin;
            this.Instagram = cliente.Instagram;

            foreach (var telefone in cliente.Telefones)
            {
                this.Telefones.Add(new TelefoneModel
                {
                    IdentificacaoTelefone = telefone.IdentificacaoTelefone,
                    DDD = telefone.DDD,
                    Telefone = telefone.NumeroTelefone
                });
            }

            foreach (var endereco in cliente.Enderecos)
            {
                this.Enderecos.Add(new EnderecoModel
                {
                    NomeEndereco = endereco.IdentificacaoEndereco,
                    Logradouro = endereco.Logradouro,
                    Numero = endereco.Numero,
                    Bairro = endereco.Bairro,
                    CEP = endereco.CEP,
                    Cidade = endereco.Cidade,
                    Complemento = endereco.Complemento,
                    Estado = endereco.Estado
                });
            }
        }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var result = new List<ValidationResult>();

            if (!this.Enderecos.Any())
            {
                result.Add(new ValidationResult("Preencha pelo menos um endereço."));
            }

            return result;
        }
    }
}
