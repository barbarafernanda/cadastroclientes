﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CadastroClientes.Data
{
    public class Cliente
    {
        public Cliente()
        {
            this.Enderecos = new List<Endereco>();
            this.Telefones = new List<Telefone>();
        }

        public int ID { get; set; }
        public string Nome { get; set; }
        public DateTime? DataNascimento { get; set; }
        public IList<Endereco> Enderecos { get; set; }
        public IList<Telefone> Telefones { get; set; }
        public string RG { get; set; }
        public string CPF { get; set; }

        public string Facebook { get; set; }
        public string Linkedin { get; set; }
        public string Twitter { get; set; }
        public string Instagram { get; set; }
    }
}
