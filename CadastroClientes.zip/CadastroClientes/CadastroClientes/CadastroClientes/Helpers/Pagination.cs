﻿using CadastroClientes.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CadastroClientes.Helpers
{
    public static class PaginationHelper
    {
        public static Pagination<TEntity> Pagination<TEntity>(this IEnumerable<TEntity> model, int currentPage) where TEntity : class
        {
            int count = model.Count();
            var page = new Pagination<TEntity>
            {
                current = currentPage
            };

            page.rowCount = page.rowCount;
            page.total = (int)Math.Ceiling(count / (double)page.rowCount);
            var items = model.Skip((page.current - 1) * page.rowCount).Take(page.rowCount).ToList();
            page.rows = items;
            return page;
        }
    }

    public class Pagination<TEntity> where TEntity : class
    {
        public IList<TEntity> rows { get; set; }
        public int current { get; set; } = 1;
        public int rowCount { get; set; } = 10;
        public int total { get; set; } = 0;
    }
}
   

    