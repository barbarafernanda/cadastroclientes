﻿(function () {
    $("#grid-data").bootgrid();



    $("#addtelefone").on("click", function (e) {
        var template = $("#telefoneField").find("#telefoneRows").first();
        var newTelefoneField = template.clone(true);
        newTelefoneField.find("input.form-control").val("");
        $("#telefoneField").prepend(newTelefoneField);
    });

    $("#addendereco").click(function (e) {
        e.preventDefault();
        var template = $("#enderecoField").find("#enderecoRows").first();
        var newEnderecoField = template.clone();
        newEnderecoField.find("input.form-control").val("");
        $("#enderecoField").prepend(newEnderecoField);
    });

    $("#btnSalvar").click(function (e) {
        e.preventDefault();
        var _this = $(this);

        if ($('#clientForm')[0].checkValidity()) {
            var url = _this.closest("form").attr("action");

            var enderecoItems = $("#enderecoRows");
            var telefoneItems = $("#telefoneField").find("#telefoneRows");
            var telefoneRows = [];
            var enderecoRows = [];

            $.each(enderecoItems, function (i, item) {
                var nomeEndereco = $(item).find("input[name='nomeendereco']").val();
                var logradouro = $(item).find("input[name='logradouro']").val();
                var numero = $(item).find("input[name='numero']").val();
                var complemento = $(item).find("input[name='complemento']").val();
                var cep = $(item).find("input[name='cep']").val();
                var bairro = $(item).find("input[name='bairro']").val();
                var cidade = $(item).find("input[name='cidade']").val();
                var estado = $(item).find("input[name='estado']").val();

                var row = {
                    NomeEndereco: nomeEndereco,
                    Logradouro: logradouro,
                    Numero: numero,
                    Complemento: complemento,
                    CEP: cep,
                    Bairro: bairro,
                    Cidade: cidade,
                    Estado: estado
                };

                enderecoRows.push(row);
            });

            $.each(telefoneItems, function (i, item) {
                var identificacaoTelefone = $(item).find("input[name='identificacaotelefone']").val();
                var DDD = $(item).find("input[name='ddd']").val();
                var Numero = $(item).find("input[name='numerotelefone']").val();

                var row = { IdentificacaoTelefone: identificacaoTelefone, DDD: DDD, Telefone: Numero };
                telefoneRows.push(row);
            });

            var model =
            {
                Nome: $("#nome").val(),
                DataNascimento: $("#dataNascimento").val(),
                RG: $("#rg").val(),
                CPF: $("#cpf").val(),
                Facebook: $("#facebook").val(),
                Linkedin: $("#linkedin").val(),
                Twitter: $("#twitter").val(),
                Instagram: $("#instagram").val(),
                Enderecos: enderecoRows,
                Telefones: telefoneRows
            };

            $.ajax({
                type: "POST",
                url: url,
                data: JSON.stringify(model),
                contentType: "application/json"
            })
                .done(function (result) {
                    $("#clientForm").append("<span>" + result.message + "</span>");
                })

        }
        else {
            return false;
        }

    });    
})();