﻿using CadastroClientes.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CadastroClientes.Helpers
{
    public static class PaginationHelper
    {
        public static Pagination<TEntity> Pagination<TEntity>(this IEnumerable<TEntity> model, int currentPage) where TEntity : class
        {
            int count = model.Count();
            var page = new Pagination<TEntity>
            {
                Page = new PageSetting
                {
                    current = currentPage
                }
            };

            page.Page.rowCount = page.Page.rowCount;
            page.Page.TotalCount = count;
            page.Page.total = (int)Math.Ceiling(count / (double)page.Page.rowCount);
            var items = model.Skip((page.Page.current - 1) * page.Page.rowCount).Take(page.Page.rowCount).ToList();
            page.Page.PreviousPage = page.Page.current > 1;
            page.Page.NextPage = page.Page.current < page.Page.total;
            page.rows = items;
            return page;
        }
    }

    public class Pagination<TEntity> where TEntity : class
    {
        public object rows { get; set; }
        public PageSetting Page { get; set; }
    }

    public class PageSetting
    {
        public int PageNumber { get; set; } = 1;
        public int rowCount { get; set; } = 10;
        public int TotalCount { get; set; } = 0;
        public int current { get; set; } = 1;
        public int total { get; set; } = 0;
        public bool PreviousPage { get; set; } = false;
        public bool NextPage { get; set; } = false;
    }


}


