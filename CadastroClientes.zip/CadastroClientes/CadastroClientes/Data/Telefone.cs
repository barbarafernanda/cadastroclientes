﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CadastroClientes.Data
{
    public class Telefone
    {
        public int ID { get; set; }
        public string IdentificacaoTelefone { get; set; }
        public string DDD { get; set; }
        public string NumeroTelefone { get; set; }
    }
}
